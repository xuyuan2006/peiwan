<?php
/**
 * 陪玩入驻申请
 * @var array|null $profile
 */
$__me = user();
?>
<div class="page-head">
  <h1>成为陪玩</h1>
  <p class="muted">提交资料后由平台审核，通过后即可上架技能、接单赚钱</p>
</div>

<div class="detail-grid">
  <section class="card">
    <?php if ($profile && (int) $profile['audit_status'] === 0): ?>
      <div class="alert alert-info">你的申请正在审核中，审核期间可以继续修改资料。</div>
    <?php elseif ($profile && (int) $profile['audit_status'] === 1): ?>
      <div class="alert alert-success">你已通过审核，可以到 <a href="<?= e(url('companion/skills')) ?>">技能管理</a> 上架服务。</div>
    <?php elseif ($profile && (int) $profile['audit_status'] === 2): ?>
      <div class="alert alert-error">申请被拒绝：<?= e($profile['audit_remark'] !== '' ? $profile['audit_remark'] : '资料不符合要求') ?>，可修改后重新提交。</div>
    <?php endif; ?>

    <form method="post" action="<?= e(url('user/apply')) ?>">
      <?= csrf_field() ?>
      <div class="form-row">
        <label>真实姓名 <span class="req">*</span></label>
        <input type="text" name="real_name" value="<?= e($profile['real_name'] ?? '') ?>" maxlength="50" placeholder="用于实名核验" required>
      </div>
      <div class="form-row">
        <label>身份证号</label>
        <input type="text" name="id_card" value="<?= e($profile['id_card'] ?? '') ?>" maxlength="30" placeholder="选填，仅平台可见">
      </div>
      <div class="form-row">
        <label>联系手机号 <span class="req">*</span></label>
        <input type="text" name="phone" value="<?= e($profile['phone'] ?? ($__me['phone'] ?? '')) ?>" maxlength="20" required>
      </div>
      <div class="form-row">
        <label>性别</label>
        <select name="gender">
          <?php $g = (int) ($profile['gender'] ?? $__me['gender']); ?>
          <option value="0" <?= $g === 0 ? 'selected' : '' ?>>保密</option>
          <option value="1" <?= $g === 1 ? 'selected' : '' ?>>男</option>
          <option value="2" <?= $g === 2 ? 'selected' : '' ?>>女</option>
        </select>
      </div>
      <div class="form-row">
        <label>所在城市</label>
        <input type="text" name="city" value="<?= e($profile['city'] ?? '') ?>" maxlength="50" placeholder="例如：上海">
      </div>
      <div class="form-row">
        <label>个人标签</label>
        <input type="text" name="tags" value="<?= e($profile['tags'] ?? '') ?>" maxlength="200" placeholder="逗号分隔，例如：技术好,声音甜,带飞">
      </div>
      <div class="form-row">
        <label>个人介绍</label>
        <textarea name="intro" rows="4" maxlength="500" placeholder="擅长的游戏、段位、服务风格、在线时间段等"><?= e($profile['intro'] ?? '') ?></textarea>
      </div>
      <button class="btn btn-primary" type="submit"><?= $profile ? '保存并重新提交' : '提交申请' ?></button>
    </form>
  </section>

  <aside class="detail-side">
    <section class="card">
      <h2 class="card-title">入驻要求</h2>
      <ol class="tips">
        <li>年满 18 周岁，需实名认证。</li>
        <li>提供真实有效的联系方式，方便平台与用户联系。</li>
        <li>禁止代练外挂、代打他人账号等违规服务。</li>
        <li>严禁任何擦边、涉黄、涉赌内容，违者永久封禁。</li>
        <li>服务时间内需保持在线，爽约会影响信用分与推荐权重。</li>
      </ol>
    </section>
  </aside>
</div>
