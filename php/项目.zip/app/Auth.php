<?php
/**
 * 登录态管理：前台用户与后台管理员共用 users 表，用 role 区分。
 */
declare(strict_types=1);

namespace App;

class Auth
{
    /** @var array<string,mixed>|null */
    private static $user = null;

    private static $loaded = false;

    public static function boot(): void
    {
        if (session_status() !== PHP_SESSION_ACTIVE) {
            $secure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
            session_set_cookie_params([
                'lifetime' => 0,
                'path'     => '/',
                'httponly' => true,
                'secure'   => $secure,
                'samesite' => 'Lax',
            ]);
            session_name('PEIWAN_SID');
            session_start();
        }
    }

    /** @return array<string,mixed>|null */
    public static function user()
    {
        if (self::$loaded) {
            return self::$user;
        }
        self::$loaded = true;

        $uid = (int) ($_SESSION['uid'] ?? 0);
        if ($uid <= 0) {
            return self::$user = null;
        }
        $row = Db::one('SELECT * FROM users WHERE id = ? LIMIT 1', [$uid]);
        if (!$row || (int) $row['status'] !== 1) {
            unset($_SESSION['uid']);
            return self::$user = null;
        }
        return self::$user = $row;
    }

    public static function id(): int
    {
        $u = self::user();
        return $u ? (int) $u['id'] : 0;
    }

    public static function check(): bool
    {
        return self::user() !== null;
    }

    public static function isAdmin(): bool
    {
        $u = self::user();
        return $u !== null && ($u['role'] ?? '') === 'admin';
    }

    public static function isCompanion(): bool
    {
        $u = self::user();
        return $u !== null && in_array(($u['role'] ?? ''), ['companion'], true);
    }

    public static function attempt(string $account, string $password): bool
    {
        $row = Db::one(
            "SELECT * FROM users WHERE username = ? OR (phone <> '' AND phone = ?) LIMIT 1",
            [$account, $account]
        );
        if (!$row) {
            return false;
        }
        if ((int) $row['status'] !== 1) {
            return false;
        }
        if (!password_verify($password, (string) $row['password'])) {
            return false;
        }
        self::login((int) $row['id']);
        return true;
    }

    public static function login(int $uid): void
    {
        if (session_status() === PHP_SESSION_ACTIVE) {
            session_regenerate_id(true);
        }
        $_SESSION['uid'] = $uid;
        self::$user      = null;
        self::$loaded    = false;
        Db::update('users', [
            'last_login_at' => now(),
            'last_login_ip' => client_ip(),
        ], 'id = ?', [$uid]);
    }

    public static function logout(): void
    {
        unset($_SESSION['uid']);
        self::$user   = null;
        self::$loaded = false;
    }

    public static function requireLogin(): void
    {
        if (!self::check()) {
            $_SESSION['_intended'] = $_SERVER['REQUEST_URI'] ?? '';
            flash('warning', '请先登录后再操作');
            redirect(url('auth/login'));
        }
    }

    public static function requireAdmin(): void
    {
        if (!self::check()) {
            $_SESSION['_intended'] = $_SERVER['REQUEST_URI'] ?? '';
            flash('warning', '请先登录后台');
            redirect(admin_url('auth/login'));
        }
        if (!self::isAdmin()) {
            abort(403, '当前账号没有后台管理权限');
        }
    }

    /** 管理员操作日志 */
    public static function logAdmin(string $action, string $detail = ''): void
    {
        try {
            Db::insert('admin_logs', [
                'admin_id'   => self::id(),
                'action'     => mb_substr($action, 0, 100),
                'detail'     => mb_substr($detail, 0, 1000),
                'ip'         => client_ip(),
                'created_at' => now(),
            ]);
        } catch (\Throwable $e) {
            // 日志失败不影响主流程
        }
    }
}
