<?php
/**
 * 后台入口。使用 ?r=控制器/方法 路由。
 */
declare(strict_types=1);

require dirname(__DIR__, 2) . '/app/bootstrap.php';

if (!\App\Db::tableExists('users')) {
    redirect(base_url() . '/install.php');
}

\App\Router::dispatch((string) ($_GET['r'] ?? 'dashboard/index'), 'App\\Controllers\\Admin\\');
